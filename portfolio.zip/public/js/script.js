// DOM 요소 선택
const contactBtn = document.querySelector('.contact-btn');
const contactModal = document.getElementById('contactModal');
const closeModalBtn = document.getElementById('closeModal');
const contactForm = document.getElementById('contactForm');
const formSuccess = document.getElementById('formSuccess');
const formError = document.getElementById('formError');
const controlToggles = document.querySelectorAll('.control-toggle');
const portfolioImage = document.querySelector('.portfolio-image');
const leftArrow = document.querySelector('.arrow-btn.left');
const rightArrow = document.querySelector('.arrow-btn.right');
const socialUnlockBtn = document.getElementById('socialUnlockBtn');
const socialLockContainer = document.querySelector('.social-lock-container');
const socialCard = document.getElementById('socialCard');
const socialIcons = document.querySelector('.social-icons');
const portfolioUnlockBtn = document.getElementById('portfolioUnlockBtn');
const portfolioLockContainer = document.querySelector('.portfolio-lock-container');
const portfolioSection = document.querySelector('.portfolio-section');
const bottomUnlockBtn1 = document.getElementById('bottomUnlockBtn1');
const bottomUnlockBtn2 = document.getElementById('bottomUnlockBtn2');
const bottomLockContainer1 = document.querySelector('.bottom-lock-container-1');
const bottomLockContainer2 = document.querySelector('.bottom-lock-container-2');
const bottomCard1 = document.getElementById('bottomCard1');
const bottomCard2 = document.getElementById('bottomCard2');
const sidebarUnlockBtn = document.getElementById('sidebarUnlockBtn');
const sidebarLockContainer = document.querySelector('.sidebar-lock-container');
const sidebarCard = document.getElementById('sidebarCard');
const leds = document.querySelectorAll('.led');
const steamElements = document.querySelectorAll('.steam');
const miniSparks = document.querySelectorAll('.mini-spark');
const spaceshipWindow = document.getElementById('spaceshipWindow');
const astronaut = document.getElementById('astronaut');
const satellite = document.querySelector('.satellite');
const smallSatellite = document.querySelector('.small-satellite');
const portfolioNavBtns = document.querySelectorAll('.nav-btn');
const portfolioItems = document.querySelectorAll('.portfolio-item');

// 포트폴리오 이미지 배열 (샘플 이미지 - 실제 프로젝트에서는 자신의 이미지로 교체)
const portfolioImages = [
    'https://via.placeholder.com/800x500/3a3aff/ffffff?text=Space+Mission+1',
    'https://via.placeholder.com/800x500/2bcc8f/ffffff?text=Space+Mission+2',
    'https://via.placeholder.com/800x500/ffcc33/ffffff?text=Space+Mission+3',
    'https://via.placeholder.com/800x500/ff6b6b/ffffff?text=Space+Mission+4'
];

// 현재 표시된 포트폴리오 이미지 인덱스
let currentImageIndex = 0;

// 페이지 로드 시 초기화
window.addEventListener('DOMContentLoaded', () => {
    // 초기 이미지 설정
    if (portfolioImage) {
        portfolioImage.src = portfolioImages[currentImageIndex];
    }
    
    // 이벤트 리스너 등록
    setupEventListeners();
    
    // 별 생성
    createStars();
    
    // 언락 상태 확인
    checkUnlockStatus();
    
    // 사용자 경험을 위해 모바일에서는 커스텀 커서 비활성화
    if (window.innerWidth > 768) {
        createCustomCursor();
    }
    
    // 위성 인터랙션 이벤트 추가
    setupSatelliteInteractions();
    
    // 포트폴리오 네비게이션 이벤트 추가
    setupPortfolioNavigation();
    
    // 포트폴리오 3D 효과를 위한 마우스 이벤트 설정
    setupPortfolio3DEffect();
});

// 이벤트 리스너 설정
function setupEventListeners() {
    // 연락하기 모달 열기
    if (contactBtn) {
        contactBtn.addEventListener('click', openContactModal);
    }
    
    // 연락하기 모달 닫기
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeContactModal);
    }
    
    // 모달 바깥쪽 클릭 시 닫기
    window.addEventListener('click', (e) => {
        if (e.target === contactModal) {
            closeContactModal();
        }
    });
    
    // 연락 폼 제출
    if (contactForm) {
        contactForm.addEventListener('submit', handleFormSubmit);
    }
    
    // 컨트롤 토글 버튼
    controlToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            toggle.classList.toggle('active');
            // 토글 사운드 재생
            playSound('https://assets.mixkit.co/sfx/preview/mixkit-select-click-1109.mp3', 0.3);
        });
    });
    
    // 포트폴리오 이미지 네비게이션
    if (leftArrow && rightArrow) {
        leftArrow.addEventListener('click', showPreviousImage);
        rightArrow.addEventListener('click', showNextImage);
    }
    
    // 소셜 카드 잠금 해제
    if (socialUnlockBtn) {
        socialUnlockBtn.addEventListener('click', () => unlockSection(
            socialUnlockBtn, 
            socialLockContainer, 
            socialCard, 
            'social-3d', 
            showSocialContent
        ));
    }
    
    // 포트폴리오 섹션 잠금 해제
    if (portfolioUnlockBtn) {
        portfolioUnlockBtn.addEventListener('click', () => unlockSection(
            portfolioUnlockBtn, 
            portfolioLockContainer, 
            portfolioSection, 
            'portfolio-3d'
        ));
    }
    
    // 하단 카드 1 잠금 해제
    if (bottomUnlockBtn1) {
        bottomUnlockBtn1.addEventListener('click', () => unlockSection(
            bottomUnlockBtn1, 
            bottomLockContainer1, 
            bottomCard1, 
            'bottom-3d'
        ));
    }
    
    // 하단 카드 2 잠금 해제
    if (bottomUnlockBtn2) {
        bottomUnlockBtn2.addEventListener('click', () => unlockSection(
            bottomUnlockBtn2, 
            bottomLockContainer2, 
            bottomCard2, 
            'bottom-3d'
        ));
    }
    
    // 사이드바 잠금 해제
    if (sidebarUnlockBtn) {
        sidebarUnlockBtn.addEventListener('click', () => unlockSection(
            sidebarUnlockBtn, 
            sidebarLockContainer, 
            sidebarCard, 
            'sidebar-3d'
        ));
    }
    
    // 우주선 창문 클릭 - 우주비행사 인사
    if (spaceshipWindow) {
        spaceshipWindow.addEventListener('click', greetAstronaut);
    }
}

// 별 생성 (추가 별을 동적으로 생성)
function createStars() {
    // 여기에 추가 별 생성 코드 (옵션)
}

// 연락하기 모달 열기
function openContactModal() {
    contactModal.classList.add('active');
    document.body.style.overflow = 'hidden'; // 페이지 스크롤 방지
    
    // 폼 리셋
    contactForm.reset();
    formSuccess.classList.remove('active');
    formError.classList.remove('active');
    contactForm.style.display = 'block';
    
    // 모달 열기 사운드 재생
    playSound('https://assets.mixkit.co/sfx/preview/mixkit-sci-fi-interface-zoom-890.mp3', 0.5);
}

// 연락하기 모달 닫기
function closeContactModal() {
    contactModal.classList.remove('active');
    document.body.style.overflow = ''; // 페이지 스크롤 복구
    
    // 모달 닫기 사운드 재생
    playSound('https://assets.mixkit.co/sfx/preview/mixkit-tech-click-1140.mp3', 0.3);
}

// 폼 제출 처리
function handleFormSubmit(e) {
    e.preventDefault();
    
    // 이 예제에서는 실제 데이터를 전송하지 않고 가상의 성공 메시지를 표시합니다.
    // 실제 구현 시에는 fetch API나 axios 등을 사용해 서버에 데이터를 전송하세요.
    
    // 로딩 효과를 위한 시간 지연 (실제 구현에서는 필요 없음)
    const submitBtn = contactForm.querySelector('.submit-btn');
    submitBtn.textContent = '전송 중...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        submitBtn.textContent = '전송 완료!';
        submitBtn.disabled = false;
        
        // 성공 메시지 표시 (랜덤하게 성공 또는 오류 메시지 표시)
        const isSuccess = Math.random() > 0.2; // 80% 확률로 성공
        
        if (isSuccess) {
            formSuccess.classList.add('active');
            contactForm.style.display = 'none';
            
            // 성공 사운드 재생
            playSound('https://assets.mixkit.co/sfx/preview/mixkit-sci-fi-confirmation-914.mp3', 0.5);
        } else {
            formError.classList.add('active');
            
            // 에러 사운드 재생
            playSound('https://assets.mixkit.co/sfx/preview/mixkit-sci-fi-reject-notification-896.mp3', 0.5);
        }
        
        // 3초 후 버튼 텍스트 복원
        setTimeout(() => {
            submitBtn.textContent = '전송';
            submitBtn.innerHTML = '전송 <i class="fas fa-paper-plane"></i>';
        }, 3000);
    }, 1500);
}

// 이전 포트폴리오 이미지 표시
function showPreviousImage() {
    currentImageIndex = (currentImageIndex - 1 + portfolioImages.length) % portfolioImages.length;
    updatePortfolioImage();
    
    // 전환 사운드 재생
    playSound('https://assets.mixkit.co/sfx/preview/mixkit-tech-click-1140.mp3', 0.3);
}

// 다음 포트폴리오 이미지 표시
function showNextImage() {
    currentImageIndex = (currentImageIndex + 1) % portfolioImages.length;
    updatePortfolioImage();
    
    // 전환 사운드 재생
    playSound('https://assets.mixkit.co/sfx/preview/mixkit-tech-click-1140.mp3', 0.3);
}

// 포트폴리오 이미지 업데이트
function updatePortfolioImage() {
    // 이미지 페이드 아웃 효과
    portfolioImage.style.opacity = '0';
    
    setTimeout(() => {
        portfolioImage.src = portfolioImages[currentImageIndex];
        
        // 이미지 로드 후 페이드 인 효과
        portfolioImage.onload = () => {
            portfolioImage.style.opacity = '1';
        };
    }, 300);
}

// 일반화된 잠금 해제 함수
function unlockSection(unlockBtn, lockContainer, sectionElement, threeDClass, callback) {
    // 버튼 누름 효과
    unlockBtn.classList.add('unlock-button-pressed');
    
    // 메커니즘 사운드 재생
    playSound('https://assets.mixkit.co/sfx/preview/mixkit-electronic-retro-block-hit-2185.mp3', 0.6);
    
    // 0.5초 후에 버튼 상태 복원
    setTimeout(() => {
        unlockBtn.classList.remove('unlock-button-pressed');
    }, 500);
    
    // 해당 섹션의 LED 라이트 찾기
    const sectionLeds = unlockBtn.closest('.shutter-door').querySelectorAll('.led');
    const sectionSteam = unlockBtn.closest('.shutter-door').querySelectorAll('.steam');
    const sectionSparks = unlockBtn.closest('.shutter-door').querySelectorAll('.mini-spark');
    
    // LED 라이트 활성화
    setTimeout(() => {
        // LED 하나씩 켜지는 효과
        sectionLeds.forEach((led, index) => {
            setTimeout(() => {
                led.classList.add('led-active');
                
                // 마지막 LED가 켜진 후 스팀 이펙트 활성화
                if (index === sectionLeds.length - 1) {
                    setTimeout(() => {
                        // 스팀 이펙트 활성화
                        sectionSteam.forEach(steam => {
                            steam.classList.add('steam-active');
                        });
                        
                        // 스팀 사운드 재생
                        playSound('https://assets.mixkit.co/sfx/preview/mixkit-jet-engine-turbine-start-up-1720.mp3', 0.3);
                        
                        // 셔터 문 열기
                        setTimeout(() => {
                            // 셔터 열리는 사운드 재생
                            playSound('https://assets.mixkit.co/sfx/preview/mixkit-gate-latch-click-1924.mp3', 0.5);
                            
                            // 스파크 이펙트 설정
                            setupSectionSparkEffects(sectionSparks);
                            
                            // 셔터 문 애니메이션 시작
                            lockContainer.classList.add('opening');
                            
                            // 섹션 준비
                            sectionElement.classList.add('unlocking');
                            
                            // 셔터가 열린 후 섹션 활성화
                            setTimeout(() => {
                                lockContainer.classList.add('unlocked');
                                sectionElement.classList.add('unlocked');
                                sectionElement.classList.add(threeDClass);
                                
                                // 콘텐츠 등장 사운드
                                playSound('https://assets.mixkit.co/sfx/preview/mixkit-magical-atmosphere-sound-709.mp3', 0.4);
                                
                                // 콜백 함수 실행 (존재하는 경우)
                                if (callback) callback();
                                
                                // 3D 효과 추가
                                setupSection3DEffect(sectionElement);
                            }, 1200);  // 셔터 문이 완전히 열리는 데 걸리는 시간
                        }, 1000);  // 스팀 이펙트 후 셔터 열기까지 시간
                    }, 300);  // 마지막 LED 켜진 후 딜레이
                }
            }, index * 150);  // LED 켜지는 시간 간격
        });
    }, 300);  // 버튼 누른 후 LED 켜지기 시작하는 시간
}

// 소셜 아이콘 표시 함수
function showSocialContent() {
    // 소셜 아이콘 표시
    setTimeout(() => {
        socialIcons.classList.remove('hidden');
        socialIcons.classList.add('visible');
        
        // 소셜 아이콘 등장 사운드 효과
        playSound('https://assets.mixkit.co/sfx/preview/mixkit-game-treasure-coin-2038.mp3', 0.5);
    }, 500);
}

// 섹션별 스파크 이펙트 설정
function setupSectionSparkEffects(sparks) {
    // 각 스파크에 랜덤한 위치와 애니메이션 설정
    sparks.forEach(spark => {
        // 랜덤한 시작 위치 설정
        const startX = Math.random() * 100 - 50; // -50 ~ 50
        const startY = Math.random() * 100 - 50; // -50 ~ 50
        
        spark.style.left = `calc(50% + ${startX}px)`;
        spark.style.top = `calc(50% + ${startY}px)`;
        
        // 랜덤한 이동 방향 설정
        const tx = (Math.random() - 0.5) * 100; // -50 ~ 50
        const ty = (Math.random() - 0.5) * 100; // -50 ~ 50
        
        spark.style.setProperty('--tx', `${tx}px`);
        spark.style.setProperty('--ty', `${ty}px`);
        
        // 애니메이션 딜레이 설정
        const delay = Math.random() * 1.2;
        spark.style.animationDelay = `${delay}s`;
    });
    
    // 추가 스파크 사운드 재생
    setTimeout(() => {
        playSound('https://assets.mixkit.co/sfx/preview/mixkit-small-electrical-spark-2596.mp3', 0.3);
    }, 400);
}

// 섹션별 3D 효과 설정
function setupSection3DEffect(element) {
    if (element && element.classList.contains('unlocked')) {
        document.addEventListener('mousemove', (e) => {
            if (element.classList.contains('unlocked')) {
                const { clientX, clientY } = e;
                const { innerWidth, innerHeight } = window;
                
                // 마우스 위치에 따른 회전값 계산
                const rotateY = ((clientX / innerWidth) - 0.5) * 8; // -4 ~ 4 도
                const rotateX = ((clientY / innerHeight) - 0.5) * -8; // -4 ~ 4 도
                
                // CSS 변수로 회전값 설정
                element.style.setProperty('--rotateX', `${rotateX}deg`);
                element.style.setProperty('--rotateY', `${rotateY}deg`);
            }
        });
    }
}

// 페이지 로드 시 잠금 해제 상태 확인
function checkUnlockStatus() {
    // 로컬 스토리지 확인 제거 (항상 잠김 상태로 시작)
}

// 우주비행사 인사 함수
function greetAstronaut() {
    if (astronaut.classList.contains('waving')) {
        return; // 이미 인사 중이면 중복 실행 방지
    }
    
    // 인사 애니메이션 추가
    astronaut.classList.add('waving');
    
    // 인사 사운드 재생
    playSound('https://assets.mixkit.co/sfx/preview/mixkit-space-coin-win-notification-271.mp3', 0.4);
    
    // 애니메이션 완료 후 클래스 제거 (재사용 가능하도록)
    setTimeout(() => {
        astronaut.classList.remove('waving');
    }, 1500);
}

// 사운드 재생 함수
function playSound(url, volume = 0.5) {
    try {
        const sound = new Audio(url);
        sound.volume = volume;
        sound.play().catch(e => {
            console.log('오디오 재생 실패: 사용자 상호작용 필요');
        });
    } catch (error) {
        console.error('사운드 재생 중 오류 발생:', error);
    }
}

// 추가 애니메이션 효과
// 카드 마우스 오버 효과
document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mouseenter', (e) => {
        if (card.classList.contains('locked')) {
            const lockIcon = card.querySelector('.lock-icon');
            lockIcon.style.transform = 'scale(1.1)';
        }
    });
    
    card.addEventListener('mouseleave', (e) => {
        if (card.classList.contains('locked')) {
            const lockIcon = card.querySelector('.lock-icon');
            lockIcon.style.transform = '';
        }
    });
});

// 마우스 따라다니는 포인터 효과 (데코레이션)
function createCustomCursor() {
    const cursor = document.createElement('div');
    cursor.classList.add('custom-cursor');
    cursor.style.position = 'fixed';
    cursor.style.width = '10px';
    cursor.style.height = '10px';
    cursor.style.borderRadius = '50%';
    cursor.style.backgroundColor = 'rgba(6, 182, 212, 0.5)';
    cursor.style.boxShadow = '0 0 20px rgba(6, 182, 212, 0.5)';
    cursor.style.pointerEvents = 'none';
    cursor.style.zIndex = '10000';
    cursor.style.transform = 'translate(-50%, -50%)';
    cursor.style.transition = 'transform 0.1s ease, opacity 0.3s ease, background-color 0.3s ease';
    
    document.body.appendChild(cursor);
    
    document.addEventListener('mousemove', (e) => {
        cursor.style.left = `${e.clientX}px`;
        cursor.style.top = `${e.clientY}px`;
    });
    
    document.addEventListener('mousedown', () => {
        cursor.style.transform = 'translate(-50%, -50%) scale(1.5)';
    });
    
    document.addEventListener('mouseup', () => {
        cursor.style.transform = 'translate(-50%, -50%) scale(1)';
    });
    
    document.addEventListener('mouseenter', () => {
        cursor.style.opacity = '1';
    });
    
    document.addEventListener('mouseleave', () => {
        cursor.style.opacity = '0';
    });
    
    // 링크 및 클릭 가능한 요소에 마우스 효과 추가
    const clickableElements = document.querySelectorAll('button, a, .control-toggle, .arrow-btn, #spaceshipWindow, #socialLock');
    
    clickableElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            cursor.style.transform = 'translate(-50%, -50%) scale(2)';
            cursor.style.backgroundColor = 'rgba(6, 182, 212, 0.7)';
            cursor.style.boxShadow = '0 0 20px rgba(6, 182, 212, 0.7)';
        });
        
        element.addEventListener('mouseleave', () => {
            cursor.style.transform = 'translate(-50%, -50%) scale(1)';
            cursor.style.backgroundColor = 'rgba(6, 182, 212, 0.5)';
            cursor.style.boxShadow = '0 0 20px rgba(6, 182, 212, 0.5)';
        });
    });
}

// 위성 인터랙션 설정
function setupSatelliteInteractions() {
    if (satellite) {
        satellite.addEventListener('click', () => {
            satellite.style.animation = 'none'; // 일시적으로 애니메이션 중지
            satellite.classList.add('glow-effect');
            
            // 위성 클릭 사운드 재생
            playSound('https://assets.mixkit.co/sfx/preview/mixkit-fast-small-sweep-transition-166.mp3', 0.3);
            
            // 잠시 후 원래 애니메이션 복원
            setTimeout(() => {
                satellite.style.animation = '';
                satellite.classList.remove('glow-effect');
            }, 1500);
        });
    }
    
    if (smallSatellite) {
        smallSatellite.addEventListener('click', () => {
            smallSatellite.style.animation = 'none'; // 일시적으로 애니메이션 중지
            smallSatellite.classList.add('glow-effect');
            
            // 작은 위성 클릭 사운드 재생
            playSound('https://assets.mixkit.co/sfx/preview/mixkit-sci-fi-click-900.mp3', 0.3);
            
            // 잠시 후 원래 애니메이션 복원
            setTimeout(() => {
                smallSatellite.style.animation = '';
                smallSatellite.classList.remove('glow-effect');
            }, 1500);
        });
    }
}

// 포트폴리오 네비게이션 설정
function setupPortfolioNavigation() {
    // 포트폴리오 네비게이션 버튼 이벤트
    portfolioNavBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // 현재 활성화된 버튼 비활성화
            const activeBtn = document.querySelector('.nav-btn.active');
            if (activeBtn) {
                activeBtn.classList.remove('active');
            }
            
            // 현재 버튼 활성화
            btn.classList.add('active');
            
            // 클릭한 버튼에 연결된 프로젝트 ID
            const targetProjectId = btn.getAttribute('data-project');
            
            // 모든 포트폴리오 아이템 숨기기
            portfolioItems.forEach(item => {
                item.classList.remove('active');
            });
            
            // 대상 포트폴리오 아이템 표시
            const targetProject = document.getElementById(targetProjectId);
            if (targetProject) {
                targetProject.classList.add('active');
                
                // 전환 사운드 재생
                playSound('https://assets.mixkit.co/sfx/preview/mixkit-tech-click-1140.mp3', 0.3);
            }
        });
    });
} 