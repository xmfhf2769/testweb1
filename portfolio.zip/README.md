# 모던 포트폴리오 대시보드

Pierre-Louis Labonne의 웹사이트를 모방한 인터랙티브 포트폴리오 대시보드입니다.

## 기능

- 모던한 UI 디자인
- 반응형 레이아웃
- 포트폴리오 이미지 슬라이더
- 연락하기 폼 (모달)
- 커스텀 애니메이션 및 인터랙션
- 스킬 토글 버튼
- 커스텀 마우스 커서 효과

## 사용 기술

- HTML5
- CSS3 (Flexbox, Grid)
- JavaScript (ES6+)
- 모바일 반응형 디자인

## 사용 방법

1. 프로젝트를 클론합니다
2. `index.html` 파일을 웹 브라우저에서 엽니다

## 커스터마이징

### 포트폴리오 이미지 변경

`public/js/script.js` 파일에서 `portfolioImages` 배열을 수정하여 자신의 프로젝트 이미지로 변경할 수 있습니다.

### 스킬 변경

`index.html` 파일에서 `.skill-item` 클래스를 가진 요소를 수정하여 스킬 목록을 변경할 수 있습니다.

### 색상 테마 변경

`public/css/style.css` 파일에서 색상 값을 변경하여 원하는 테마로 커스터마이징할 수 있습니다.

## 참고

원본 디자인은 [Pierre-Louis Labonne](https://pierrelouis.webflow.io/)의 웹사이트에서 영감을 받았습니다. 